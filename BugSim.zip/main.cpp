#include <iostream>
#include <windows.h>
#include <conio.h>
#include <ctime>    
#include "World.h"
#include <mmsystem.h>
using namespace std;


//Hides cursor in console
void ShowConsoleCursor(bool showFlag)
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO     cursorInfo;
	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = false; // set the cursor visibility
	SetConsoleCursorInfo(out, &cursorInfo);
}


int main()
{
		World myWorld(time(0));

		myWorld.display();

		char ch;

		//background music
		PlaySound(TEXT("c:\\temp\\music.wav"), NULL, SND_FILENAME | SND_ASYNC);

		while (1) {   // q for quit
			if (_kbhit())
			{
				ch = _getch();
				if (ch == 'a' || ch == 'A')
				{
					// add an ant
					myWorld.createOrganisms(ANT, 1);
				}

				else if (ch == 'b' || ch == 'B')
				{
					// add a bug
					myWorld.createOrganisms(BUG, 1);
				}

				else if (ch == 'x' || ch == 'X')
				{
					// add a bomb bug
					myWorld.createOrganisms(BOMB, 1);
				}

				else if (ch == 'r')
				{
					//resets world
					myWorld.resetWorld();
					//world destructor
					myWorld.~World();
					//displays NULL world
					myWorld.display();
					//backround music reset
					PlaySound(TEXT("c:\\temp\\music.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
			}

			//clears screen displays
			system("cls");
			//hides cursor
			ShowConsoleCursor(false);
			cout << "Alexander Robles" << endl;

			myWorld.simulateOneStep();
			myWorld.display();

			Sleep(500);
		}
    return 0;
}

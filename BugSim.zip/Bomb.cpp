//
//  Bomb.cpp
//  INHERITANCE_AND_POLYMORPHISM
//
//  Created by Kristjan Thorsteinsson on 01/04/14.
//  Copyright (c) 2014 Kristjan Thorsteinsson. All rights reserved.
//

#include "Bomb.h"
#include "Organism.h"
#include <ctime>
#include <chrono>
#include <Windows.h>


using namespace std;

Bomb::Bomb(World* aWorld, int xcoord, int ycoord) : Organism(aWorld, xcoord, ycoord)
{
	//time intialized for bomb to blow up
	timer = 5;
	//tiks it will take for omb to be considered dead
	death_tik = 6;
}

void Bomb::move()
{
	//bomb countdown
	timer--;
	//death tik used for organism cleanup function
	death_tik--;
	if (timer == -1)
	{
	
		if (y - 1 > 7)
		{
			//do nothing
			//top middle
		}
		else
		{
			//if organism is present
			if (world->getAt(x, y - 1) != NULL)
			{
				//delete organism and set it to NULL
				delete world->getAt(x, y - 1);
				world->setAt(x, y - 1, NULL);
			}
		}

		if (y + 1 > 27)
		{
			//do nothing
			// bottom middle
		}
		else
		{
			//if organism is present
			if (world->getAt(x, y + 1) != NULL)
			{
				//delete organism and set it to NULL
				delete world->getAt(x, y + 1);
				world->setAt(x, y + 1, NULL);
			}
		}

		if (x - 1 > 20)
		{
			//do nothing
			//right middle
		}
		else
		{
			//if organism is present
			if (world->getAt(x - 1, y) != NULL)
			{
					//delete organism and set it to NULL
					delete world->getAt(x - 1, y);
					world->setAt(x - 1, y,NULL);
			}
		}

		if (x + 1 > 0)
		{
			//do nothing
			//left middle
		}
		else
		{
			//if organism is present
			if (world->getAt(x + 1, y) != NULL)
			{
					//delete organism and set it to NULL
					delete world->getAt(x + 1, y);
					world->setAt(x - 1, y,NULL);
			}

		}

		if (x + 1 > 0 && y - 1 > 7)
		{
			//do nothing
			//top left
		}
		else
		{
			//if organism is present
			if (world->getAt(x + 1, y - 1) != NULL)
			{
					//delete organism and set it to NULL
					delete world->getAt(x + 1, y - 1);
					world->setAt(x + 1, y - 1, NULL);
			}

		}

		if (x - 1 > 20 && y - 1 > 7)
		{
			//do nothing
			//top right
		}
		else
		{
			//if organism is present
			if (world->getAt(x - 1, y - 1) != NULL)
			{
					//delete organism and set it to NULL
					delete world->getAt(x - 1, y - 1);
					world->setAt(x - 1, y - 1, NULL);
			}

		}

		if (x + 1 > 0 && y + 1 > 27)
		{
			//do nothing
			//bottom left 
		}
		else
		{
			//if organism is present
			if (world->getAt(x + 1, y + 1) != NULL)
			{
					//delete organism and set it to NULL
					delete world->getAt(x + 1, y + 1);
					world->setAt(x + 1, y + 1, NULL);
			}

		}

		if (x - 1 > 20 && y + 1 > 27)
		{
			//do nothing
			//bottom right 
		}
		else
		{
			//if organism is present
			if (world->getAt(x - 1, y + 1) != NULL)
			{
				//delete organism and set it to NULL
				delete world->getAt(x - 1, y + 1);
				world->setAt(x - 1, y + 1, NULL);
			}

		}

	}

	// optional --> BOMB to move or not
	/*else
	{*/
		/*if (world->getAt(x, y + 1) != NULL)
		{
			if (world->getAt(x, y + 1)->getType() == ANT)
			{
				delete world->getAt(x, y + 1);
				movesTo(x, y + 1);
				return;
			}
		}

		if (world->getAt(x, y - 1) != NULL)
		{
			if (world->getAt(x, y - 1)->getType() == ANT)
			{
				delete world->getAt(x, y - 1);
				movesTo(x, y - 1);
				return;
			}
		}

		if (world->getAt(x - 1, y) != NULL)
		{
			if (world->getAt(x - 1, y)->getType() == ANT)
			{
				delete world->getAt(x - 1, y);
				movesTo(x - 1, y);
				return;
			}
		}
		if (world->getAt(x + 1, y) != NULL)
		{
			if (world->getAt(x + 1, y)->getType() == ANT)
			{
				delete world->getAt(x + 1, y);
				movesTo(x + 1, y);
				return;
			}
		}*/

		/*Move mover = world->randomMove();
		switch (mover) {
		case UP:
			if (world->getAt(x, y + 1) == NULL && in_range(x, y + 1))
			{
				movesTo(x, y + 1);
			}
			break;
		case DOWN:
			if (world->getAt(x, y - 1) == NULL && in_range(x, y - 1))
			{
				movesTo(x, y - 1);
			}
			break;
		case LEFT:
			if (world->getAt(x - 1, y) == NULL && in_range(x - 1, y))
			{
				movesTo(x - 1, y);
			}
			break;
		case RIGHT:
			if (world->getAt(x + 1, y) == NULL && in_range(x + 1, y))
			{
				movesTo(x + 1, y);
			}
			break;
		default:
			break;
		}*/
	
}

void Bomb::generateOffspring(int whereX, int whereY)
{
	new Bomb(this->world, whereX, whereY);
}

void Bomb::breed()
{
	//Bomb bug does not breed
}

bool Bomb::isDead() const
{
	//bomb bug only dies after the timer goes off
	if (death_tik <=0)
	{
		//bomb sound
		PlaySound(TEXT("c:\\temp\\bomb.wav"), NULL, SND_FILENAME | SND_ASYNC);
		return true;
	}

	else
	{
		return false;
	}
}

OrganismType Bomb::getType() const
{
	//returns type bomb to organism type
	return BOMB;
}


char Bomb::representation()const
{
	//timer + 49 is acii representation of timer countdown
	return timer + 49;
}

int Bomb::size() const
{
	return 30;
}

bool Bomb::in_range(int xx, int yy)
{
	return (xx >= 0) && (xx < WORLDSIZE) && (yy >= 0) && (yy < WORLDSIZE);
}
